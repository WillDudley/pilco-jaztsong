from .mgpr import MGPR
# from .smgpr import SMGPR
from .pilco import PILCO
